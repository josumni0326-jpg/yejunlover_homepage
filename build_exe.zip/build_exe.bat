@echo off
chcp 65001 > nul
echo ============================================
echo   Excel to Word 보고서 생성기 EXE 빌드
echo ============================================
echo.

echo [1/2] 패키지 설치 중...
pip install -r requirements.txt

echo.
echo [2/2] EXE 빌드 중... (시간이 걸릴 수 있습니다)
pyinstaller --onefile ^
            --windowed ^
            --name "Excel보고서생성기" ^
            --add-data "." ^
            excel_to_word.py

echo.
if exist "dist\Excel보고서생성기.exe" (
    echo ============================================
    echo   빌드 완료!
    echo   파일 위치: dist\Excel보고서생성기.exe
    echo ============================================
    start "" "dist"
) else (
    echo [오류] 빌드 실패. 위 오류 메시지를 확인하세요.
)

pause
